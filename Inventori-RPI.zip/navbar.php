<nav class="top-nav">
	<ul class="icon-list">
		<li class="menu-title">Inventori RPI</li>
		<li><a class="active" href="main.php"><i class="glyphicon glyphicon-home"></i> Home </a></li>
		<li><a href="tracking.php"><i class="glyphicon glyphicon-eye-open"></i> Tracking </a></li>
		<li><a href="barangrusak.php"><i class="glyphicon glyphicon-trash"></i> Barang Rusak</a></li>
		<li><a href="about.php"><i class="glyphicon glyphicon-info-sign"></i> About </a></li>
		<li><a href="about.php"><i class="glyphicon glyphicon-log-out"></i> Log Out </a></li>
		<li><a href="tambahbarang.php"><i class="glyphicon glyphicon-plus-sign"></i> Add Barang </a></li>
	</ul>
</nav>