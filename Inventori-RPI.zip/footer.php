<div class="w3agile footer"> 
	<div class="social-icons">
		<ul>
			<li><a href="#"> </a></li>
			<li><a href="#" class="fb"> </a></li>
			<li><a href="#" class="gp"> </a></li>
			<li><a href="#" class="drb"> </a></li>
		</ul>
		<div class="clearfix"> </div>
	</div>
	<div class="footer-nav">
		<ul>  
			<li><a href="home.php"> Home </a></li>
			<li><a href="tracking.php"> Tracking </a> </li>
			<li><a href="barangrusak.php"> Barang Rusak </a></li>
			<li><a href="about.php"> About</a></li>
		</ul> 
		<div class="clearfix"> </div>
	</div>
	<div class="footer-text">
		<p>&copy; 2019 Robotika Polindra . All Rights Reserved | Created by TI.C</p>
	</div>
</div> 