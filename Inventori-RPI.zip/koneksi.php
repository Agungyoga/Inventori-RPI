<?php $koneksi = new mysqli("localhost","root","","inventori");
$password = "Pandawa1234"; ?>